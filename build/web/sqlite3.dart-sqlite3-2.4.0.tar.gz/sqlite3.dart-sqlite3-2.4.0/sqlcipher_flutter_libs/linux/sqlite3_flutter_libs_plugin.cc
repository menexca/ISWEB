#include "include/sqlcipher_flutter_libs/sqlite3_flutter_libs_plugin.h"

#include <flutter_linux/flutter_linux.h>

void sqlite3_flutter_libs_plugin_register_with_registrar(FlPluginRegistrar* registrar) {

}
