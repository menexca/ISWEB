#import <Flutter/Flutter.h>

@interface Sqlite3FlutterLibsPlugin : NSObject<FlutterPlugin>
@end
