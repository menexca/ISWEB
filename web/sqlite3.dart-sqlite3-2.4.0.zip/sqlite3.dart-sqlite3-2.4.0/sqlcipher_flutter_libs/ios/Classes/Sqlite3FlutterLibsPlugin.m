#import "Sqlite3FlutterLibsPlugin.h"

@implementation Sqlite3FlutterLibsPlugin
+ (void)registerWithRegistrar:(NSObject<FlutterPluginRegistrar>*)registrar {
  
}
@end
