#define SQLITE_API __declspec(dllexport)
#include "sqlcipher.c"
