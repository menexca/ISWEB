#define SQLITE_API __declspec(dllexport)
#include "sqlite3.c"
